# Learn Terraform Provisioning
Companion code repository for learning to provision Terraform instances with Packer

Follow along on the [HashiCorp Learn platform](https://learn.hashicorp.com/tutorials/terraform/packer?in=terraform/provision)
